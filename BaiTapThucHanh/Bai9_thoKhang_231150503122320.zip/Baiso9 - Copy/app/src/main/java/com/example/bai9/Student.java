package com.example.bai9;

public class Student {
    public String name;
    public String mssv;
    public int index;

    public Student(int index, String name, String mssv) {
        this.index = index;
        this.name = name;
        this.mssv = mssv;
    }
}
